DialogueLite 1.3
=================

WoW 3.3.5 / Interface 30300.

CONTROLS
--------
1-9    Select the corresponding visible quest or gossip option.
SPACE  Accept a quest, complete a quest, take a reward, or open a
       single quest from an NPC greeting.

VISUALS
-------
The addon puts a small yellow 1/2/3/etc. directly beside the existing
Blizzard NPC options.

IMPLEMENTATION
--------------
This version uses SetOverrideBindingClick rather than trying to capture
number keys with an OnKeyDown frame. This is important because 1-9 are
normally game/action-bar key bindings.

The addon has:
- no external libraries
- no saved variables
- no configuration UI
- no replacement dialogue window

Slash command:
  /dialoguelite
