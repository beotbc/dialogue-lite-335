-- DialogueLite 1.4
-- WoW 3.3.5 / Interface 30300
--
-- This version uses Blizzard's override-keybinding system instead of
-- OnKeyDown. That is intentional: action-bar keys such as 1/2/3 are
-- normally handled by the game's binding system, so an override binding
-- is the reliable way to make them activate NPC buttons.
--
-- 1-9 = click the corresponding visible NPC option.
-- SPACE = accept / complete / reward a quest when the relevant Blizzard
--        quest button is visible.
--
-- No libraries, no saved variables, no custom dialogue window.

local DL = CreateFrame("Frame", "DialogueLiteBindingOwner", UIParent)

local labels = {}
local boundKeys = {}

local function ClearBindings()
    if ClearOverrideBindings then
        ClearOverrideBindings(DL)
    end
    boundKeys = {}
end

local function MakeLabel(button, number)
    if not button then return end

    local label = labels[button]
    if not label then
        label = button:CreateFontString(nil, "OVERLAY")
        label:SetFont(STANDARD_TEXT_FONT, 14, "OUTLINE")
        label:SetTextColor(1, 0.82, 0)
        label:SetPoint("LEFT", button, "LEFT", 3, 0)
        label:SetJustifyH("LEFT")
        labels[button] = label
    end

    label:SetText(tostring(number))
    label:Show()
end

local function HideAllLabels()
    for _, label in pairs(labels) do
        label:Hide()
    end
end

local function BindButton(key, button)
    if not button or not button:IsShown() or not button:IsEnabled() then
        return false
    end

    local name = button:GetName()
    if not name then
        return false
    end

    -- Priority override means 1/2/3/etc. take precedence over normal
    -- action-bar bindings while this NPC dialogue is active.
    SetOverrideBindingClick(DL, true, key, name, "LeftButton")
    boundKeys[key] = name
    return true
end

local function GetGossipButtons()
    local result = {}

    for i = 1, 32 do
        local button = _G["GossipTitleButton" .. i]

        if button and button:IsShown() and button:IsEnabled() then
            result[#result + 1] = button
        end
    end

    return result
end

local function GetQuestGreetingButtons()
    local result = {}

    -- Blizzard's 3.3.5 greeting panel has separate lists for available
    -- and active quests. The visible order is represented by these buttons.
    for i = 1, 32 do
        local button = _G["QuestFrameGreetingPanelQuestButton" .. i]

        if button and button:IsShown() and button:IsEnabled() then
            result[#result + 1] = button
        end
    end

    for i = 1, 32 do
        local button = _G["QuestFrameGreetingPanelActiveQuestButton" .. i]

        if button and button:IsShown() and button:IsEnabled() then
            result[#result + 1] = button
        end
    end

    return result
end

local function GetDialogueButtons()
    local buttons = {}

    if GossipFrame and GossipFrame:IsShown() then
        buttons = GetGossipButtons()
    end

    if QuestFrameGreetingPanel and QuestFrameGreetingPanel:IsShown() then
        local questButtons = GetQuestGreetingButtons()

        for i = 1, #questButtons do
            buttons[#buttons + 1] = questButtons[i]
        end
    end

    return buttons
end

-- SPACE is bound to our own invisible button instead of directly to
-- individual Blizzard quest buttons. This makes the behavior reliable
-- across the different quest panels used by the 3.3.5 client.
local SpaceButton = CreateFrame("Button", "DialogueLiteSpaceButton", UIParent)
SpaceButton:Hide()

SpaceButton:SetScript("OnClick", function()
    if not QuestFrame or not QuestFrame:IsShown() then
        return
    end

    -- Quest detail: accept.
    if QuestFrameDetailPanel and QuestFrameDetailPanel:IsShown() then
        if QuestFrameAcceptButton and QuestFrameAcceptButton:IsShown()
            and QuestFrameAcceptButton:IsEnabled() then
            QuestFrameAcceptButton:Click()
        else
            AcceptQuest()
        end
        return
    end

    -- Quest progress: continue to the reward screen.
    if QuestFrameProgressPanel and QuestFrameProgressPanel:IsShown() then
        if QuestFrameCompleteButton and QuestFrameCompleteButton:IsShown()
            and QuestFrameCompleteButton:IsEnabled() then
            QuestFrameCompleteButton:Click()
        else
            CompleteQuest()
        end
        return
    end

    -- Quest reward: take the currently selected/default reward.
    if QuestFrameRewardPanel and QuestFrameRewardPanel:IsShown() then
        if QuestFrameCompleteQuestButton and QuestFrameCompleteQuestButton:IsShown()
            and QuestFrameCompleteQuestButton:IsEnabled() then
            QuestFrameCompleteQuestButton:Click()
        else
            GetQuestReward()
        end
        return
    end

    -- Greeting with exactly one quest: open it.
    if QuestFrameGreetingPanel and QuestFrameGreetingPanel:IsShown() then
        local buttons = GetQuestGreetingButtons()

        if #buttons == 1 then
            buttons[1]:Click()
        end
    end
end)

local function BindQuestSpace()
    if not QuestFrame or not QuestFrame:IsShown() then
        return
    end

    -- Bind SPACE to the dedicated handler. The handler determines which
    -- quest panel is currently visible and activates the correct Blizzard
    -- action for that panel.
    SetOverrideBindingClick(DL, true, "SPACE", SpaceButton:GetName(), "LeftButton")
    boundKeys["SPACE"] = SpaceButton:GetName()
end

local function Update()
    ClearBindings()
    HideAllLabels()

    local buttons = GetDialogueButtons()

    for i = 1, #buttons do
        if i <= 9 then
            MakeLabel(buttons[i], i)
            BindButton(tostring(i), buttons[i])
        end
    end

    BindQuestSpace()
end

local function HideLabelsIfClosed()
    if not ((GossipFrame and GossipFrame:IsShown()) or
            (QuestFrame and QuestFrame:IsShown())) then
        ClearBindings()
        HideAllLabels()
    end
end

-- Polling is deliberately tiny (10 times/sec) because 3.3.5's NPC frames
-- can be populated after the initial gossip/quest event.
local elapsed = 0

DL:SetScript("OnUpdate", function(self, delta)
    elapsed = elapsed + delta

    if elapsed < 0.10 then
        return
    end

    elapsed = 0

    if (GossipFrame and GossipFrame:IsShown()) or
       (QuestFrame and QuestFrame:IsShown()) then
        Update()
    else
        HideLabelsIfClosed()
    end
end)

DL:RegisterEvent("PLAYER_REGEN_DISABLED")
DL:RegisterEvent("PLAYER_REGEN_ENABLED")
DL:RegisterEvent("GOSSIP_SHOW")
DL:RegisterEvent("QUEST_GREETING")
DL:RegisterEvent("QUEST_DETAIL")
DL:RegisterEvent("QUEST_PROGRESS")
DL:RegisterEvent("QUEST_COMPLETE")

DL:SetScript("OnEvent", function(self, event)
    -- Override bindings are protected during combat. Dialogue normally
    -- happens out of combat, but clear them if combat begins.
    if event == "PLAYER_REGEN_DISABLED" then
        ClearBindings()
        HideAllLabels()
        return
    end

    if event == "PLAYER_REGEN_ENABLED" then
        elapsed = 0
        return
    end

    elapsed = 0
end)

SLASH_DIALOGUELITE1 = "/dialoguelite"
SlashCmdList["DIALOGUELITE"] = function()
    DEFAULT_CHAT_FRAME:AddMessage("|cff66ccffDialogueLite 1.4|r loaded. NPC controls: 1-9 = option, SPACE = quest accept/complete/reward.")
end
